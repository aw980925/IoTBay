/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  yoonkoo
 * Created: 26/05/2020
 */

INSERT INTO USERS(fName,lName,password,email,mobileNum,address)
    VALUES('Jane','Doe','1234','jane.doe@uts.edu.au','01234567','uts1')
,('Helen','Strokes','1234', 'helen.strokes@uts.edu.au','01234567','uts1')
,('Jim','Carry','1234','jim.carry@uts.edu.au','01234567','uts1')
,('Steve','Miller','1234','steve.miller@uts.edu.au','01234567','uts1')
,('John','Smith','1234','john.smith@uts.edu.au','01234567','uts1');
