/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  yoonkoo
 * Created: 20/05/2020
 */


CREATE TABLE USERS
(fName VARCHAR(10),
lName VARCHAR(10),
password VARCHAR(20),
email VARCHAR(50),
mobileNum VARCHAR(20),
address VARCHAR(50),
PRIMARY KEY (email));
